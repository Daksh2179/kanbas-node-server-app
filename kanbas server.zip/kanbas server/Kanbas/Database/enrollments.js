export default [
  { "_id": "1", "user": "iron_man", "course_id": "CS1234" },
  { "_id": "2", "user": "iron_man", "course_id": "CS5610" },
  { "_id": "3", "user": "dark_knight", "course_id": "CS1234" },
  { "_id": "4", "user": "dark_knight", "course_id": "CS5610" },
  { "_id": "5", "user": "black_widow", "course_id": "CS1234" },
  { "_id": "6", "user": "black_widow", "course_id": "CS5610" },
  { "_id": "7", "user": "thor_odinson", "course_id": "CS1234" },
  { "_id": "8", "user": "thor_odinson", "course_id": "CS5610" },
  { "_id": "9", "user": "hulk_smash", "course_id": "CS1234" },
  { "_id": "10", "user": "hulk_smash", "course_id": "CS5610" },
  { "_id": "11", "user": "ring_bearer", "course_id": "CS1234" },
  { "_id": "12", "user": "ring_bearer", "course_id": "CS5610" },
  { "_id": "13", "user": "strider", "course_id": "CS1234" },
  { "_id": "14", "user": "strider", "course_id": "CS5610" },
  { "_id": "15", "user": "elf_archer", "course_id": "CS1234" },
  { "_id": "16", "user": "elf_archer", "course_id": "CS5610" }
];
